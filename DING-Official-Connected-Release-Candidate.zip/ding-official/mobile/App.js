import React, { useEffect, useMemo, useState } from 'react';
import { ActivityIndicator, Alert, Pressable, SafeAreaView, ScrollView, StyleSheet, Text, TextInput, View } from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import * as SecureStore from 'expo-secure-store';
import { StatusBar } from 'expo-status-bar';

const API_URL = 'http://localhost:4000';
const TOKEN_KEY = 'ding.auth.token';
const LOCAL_STATE_KEY = 'ding.local.state';

const FALLBACK = {
  direction: 'Build a life you are proud to wake up to.',
  habits: [
    { id: 'focus', title: 'One focused hour', meta: 'Protect your attention', done: false },
    { id: 'learn', title: 'Learn something useful', meta: '20 minutes', done: false },
    { id: 'move', title: 'Move your body', meta: 'Walk, train, or stretch', done: false }
  ],
  areas: [
    { id: 'mind', title: 'Mind', progress: 42 },
    { id: 'health', title: 'Health', progress: 28 },
    { id: 'work', title: 'Work', progress: 35 },
    { id: 'relationships', title: 'Relationships', progress: 58 }
  ],
  saved: []
};

async function api(path, options = {}, token) {
  const response = await fetch(`${API_URL}${path}`, {
    ...options,
    headers: { 'Content-Type': 'application/json', ...(token ? { Authorization: `Bearer ${token}` } : {}), ...(options.headers || {}) }
  });
  const data = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(data.error || 'Something went wrong.');
  return data;
}

function Logo() { return <View style={styles.logo}><Text style={styles.logoText}>D</Text></View>; }
function Button({ children, onPress, secondary = false, disabled = false }) { return <Pressable disabled={disabled} onPress={onPress} style={[styles.button, secondary && styles.buttonSecondary, disabled && { opacity: 0.45 }]}><Text style={[styles.buttonText, secondary && styles.buttonSecondaryText]}>{children}</Text></Pressable>; }
function Card({ children, style }) { return <View style={[styles.card, style]}>{children}</View>; }
function Progress({ value }) { return <View style={styles.progressTrack}><View style={[styles.progressFill, { width: `${Math.max(0, Math.min(100, value))}%` }]} /></View>; }

function Auth({ onAuthed }) {
  const [mode, setMode] = useState('login');
  const [name, setName] = useState(''); const [email, setEmail] = useState(''); const [password, setPassword] = useState(''); const [busy, setBusy] = useState(false);
  async function submit() {
    if (!email || !password || (mode === 'signup' && !name)) return Alert.alert('Almost there', 'Fill in the required fields.');
    setBusy(true);
    try {
      const data = await api(`/v1/auth/${mode}`, { method: 'POST', body: JSON.stringify({ name, email, password }) });
      await SecureStore.setItemAsync(TOKEN_KEY, data.token);
      await AsyncStorage.setItem(LOCAL_STATE_KEY, JSON.stringify(data.state));
      onAuthed({ user: data.user, token: data.token, state: data.state, version: data.version });
    } catch (e) { Alert.alert('DING', e.message); } finally { setBusy(false); }
  }
  return <SafeAreaView style={styles.safe}><StatusBar style="dark" /><ScrollView contentContainerStyle={styles.authWrap} keyboardShouldPersistTaps="handled">
    <Logo /><Text style={styles.kicker}>YOUR LIFE, DESIGNED</Text><Text style={styles.hero}>Make today{`\n`}mean something.</Text><Text style={styles.sub}>DING turns direction into understanding, action, and habits that compound.</Text>
    <Card style={styles.authCard}>{mode === 'signup' && <TextInput value={name} onChangeText={setName} placeholder="Your name" placeholderTextColor="#8C8C87" style={styles.input} />}
      <TextInput value={email} onChangeText={setEmail} autoCapitalize="none" keyboardType="email-address" placeholder="Email" placeholderTextColor="#8C8C87" style={styles.input} />
      <TextInput value={password} onChangeText={setPassword} secureTextEntry placeholder="Password (8+ characters)" placeholderTextColor="#8C8C87" style={styles.input} />
      <Button disabled={busy} onPress={submit}>{busy ? 'Working…' : mode === 'login' ? 'Enter DING' : 'Create my DING'}</Button>
      <Pressable onPress={() => setMode(mode === 'login' ? 'signup' : 'login')}><Text style={styles.switch}>{mode === 'login' ? 'New here? Create an account' : 'Already have an account? Sign in'}</Text></Pressable>
    </Card><Text style={styles.tiny}>Your account stores your DING state so your progress can follow you across sessions.</Text>
  </ScrollView></SafeAreaView>;
}

function Today({ state, setState }) {
  const completed = state.habits.filter(h => h.done).length;
  const toggle = id => setState(s => ({ ...s, habits: s.habits.map(h => h.id === id ? { ...h, done: !h.done } : h) }));
  return <ScrollView contentContainerStyle={styles.content} showsVerticalScrollIndicator={false}>
    <Text style={styles.kicker}>TODAY</Text><Text style={styles.title}>Move your life forward.</Text>
    <Card style={styles.direction}><Text style={styles.cardLabel}>YOUR DIRECTION</Text><Text style={styles.directionText}>{state.direction}</Text><Text style={styles.muted}>The goal is not to do everything. It is to do what matters next.</Text></Card>
    <View style={styles.rowBetween}><Text style={styles.sectionTitle}>Today’s habits</Text><Text style={styles.muted}>{completed}/{state.habits.length}</Text></View>
    {state.habits.map(h => <Pressable key={h.id} onPress={() => toggle(h.id)} style={styles.habitRow}><View style={[styles.check, h.done && styles.checkDone]}>{h.done && <Text style={styles.checkMark}>✓</Text>}</View><View style={{ flex: 1 }}><Text style={[styles.habitTitle, h.done && styles.done]}>{h.title}</Text><Text style={styles.muted}>{h.meta}</Text></View></Pressable>)}
    <Text style={styles.sectionTitle}>Your life, in balance</Text>{state.areas.map(a => <Card key={a.id} style={styles.area}><View style={styles.rowBetween}><Text style={styles.habitTitle}>{a.title}</Text><Text style={styles.muted}>{a.progress}%</Text></View><Progress value={a.progress} /></Card>)}
  </ScrollView>;
}
function Life({ state }) { return <ScrollView contentContainerStyle={styles.content}><Text style={styles.kicker}>LIFE AREAS</Text><Text style={styles.title}>See the whole picture.</Text><Text style={styles.sub}>Small improvements become powerful when they reinforce each other.</Text>{state.areas.map(a => <Card key={a.id} style={styles.lifeCard}><View style={styles.bigNumber}>{a.progress}%</View><Text style={styles.sectionTitle}>{a.title}</Text><Progress value={a.progress} /><Text style={styles.muted}>Choose one meaningful action for this area today.</Text></Card>)}</ScrollView>; }
function Explore({ state, setState }) { const items = [{id:'book',tag:'BOOK',title:'The ideas worth carrying',text:'Turn useful ideas into principles you can actually practice.'},{id:'story',tag:'STORY',title:'Study people who built the life they wanted',text:'Look for the decisions, systems and habits behind the outcome.'},{id:'hack',tag:'LIFE HACK',title:'Design your environment',text:'Make the useful action easier to start and the distracting action harder to reach.'}]; const save=id=>setState(s=>({...s,saved:s.saved.includes(id)?s.saved.filter(x=>x!==id):[...s.saved,id]})); return <ScrollView contentContainerStyle={styles.content}><Text style={styles.kicker}>EXPLORE</Text><Text style={styles.title}>Better ideas. Better action.</Text><Text style={styles.sub}>Short, useful learning inspired by great books, stories and practical thinking.</Text>{items.map(i=><Card key={i.id} style={styles.exploreCard}><Text style={styles.cardLabel}>{i.tag}</Text><Text style={styles.exploreTitle}>{i.title}</Text><Text style={styles.sub}>{i.text}</Text><Pressable onPress={()=>save(i.id)}><Text style={styles.save}>{state.saved.includes(i.id)?'Saved ✓':'Save for later'}</Text></Pressable></Card>)}</ScrollView>; }
function You({ user, onLogout }) { return <ScrollView contentContainerStyle={styles.content}><Text style={styles.kicker}>YOU</Text><Text style={styles.title}>{user.name}</Text><Card><Text style={styles.cardLabel}>YOUR DING ACCOUNT</Text><Text style={styles.habitTitle}>{user.email}</Text><Text style={styles.muted}>Your progress is connected to your account.</Text></Card><Card><Text style={styles.sectionTitle}>The DING principle</Text><Text style={styles.sub}>Direction → Understanding → Action → Habit → Evidence → Reflection.</Text></Card><Button secondary onPress={onLogout}>Sign out</Button></ScrollView>; }

export default function App() {
  const [session, setSession] = useState(null); const [state, setState] = useState(FALLBACK); const [tab, setTab] = useState('Today'); const [ready, setReady] = useState(false); const [saving, setSaving] = useState(false);
  useEffect(() => { (async()=>{ try { const token=await SecureStore.getItemAsync(TOKEN_KEY); if(token){ const me=await api('/v1/me',{},token); const remote=await api('/v1/state',{},token); setSession({token,user:me.user,version:remote.version}); setState(remote.state); } else { const local=await AsyncStorage.getItem(LOCAL_STATE_KEY); if(local)setState(JSON.parse(local)); } } catch(e){ await SecureStore.deleteItemAsync(TOKEN_KEY); } finally { setReady(true); } })(); }, []);
  useEffect(() => { if(!ready || !session) return; const t=setTimeout(async()=>{ try { setSaving(true); const result=await api('/v1/state',{method:'PUT',body:JSON.stringify({state,version:session.version})},session.token); setSession(s=>({...s,version:result.version})); await AsyncStorage.setItem(LOCAL_STATE_KEY,JSON.stringify(state)); } catch(e) { if(!String(e.message).includes('conflict')) await AsyncStorage.setItem(LOCAL_STATE_KEY,JSON.stringify(state)); } finally { setSaving(false); } },500); return ()=>clearTimeout(t); },[state]);
  if(!ready) return <SafeAreaView style={styles.safe}><View style={styles.loading}><Logo/><ActivityIndicator size="small" /></View></SafeAreaView>;
  if(!session) return <Auth onAuthed={setSession} />;
  const screen = tab==='Today'?<Today state={state} setState={setState}/>:tab==='Life'?<Life state={state}/>:tab==='Explore'?<Explore state={state} setState={setState}/>:<You user={session.user} onLogout={async()=>{await SecureStore.deleteItemAsync(TOKEN_KEY);setSession(null);}}/>;
  return <SafeAreaView style={styles.safe}><StatusBar style="dark"/><View style={{flex:1}}>{screen}</View><View style={styles.nav}>{['Today','Life','Explore','You'].map(x=><Pressable key={x} onPress={()=>setTab(x)} style={styles.navItem}><View style={[styles.navDot,tab===x&&styles.navDotActive]} /><Text style={[styles.navText,tab===x&&styles.navTextActive]}>{x}</Text></Pressable>)}</View>{saving&&<Text style={styles.sync}>Syncing</Text>}</SafeAreaView>;
}

const styles=StyleSheet.create({safe:{flex:1,backgroundColor:'#F7F7F5'},loading:{flex:1,alignItems:'center',justifyContent:'center',gap:18},authWrap:{padding:28,paddingTop:64},logo:{width:42,height:42,borderRadius:14,backgroundColor:'#111',alignItems:'center',justifyContent:'center',marginBottom:28},logoText:{color:'#fff',fontSize:23,fontWeight:'800'},kicker:{fontSize:11,letterSpacing:2,fontWeight:'800',color:'#777770',marginBottom:9},hero:{fontSize:42,lineHeight:45,fontWeight:'700',letterSpacing:-1.8,color:'#111',marginBottom:14},title:{fontSize:34,lineHeight:39,fontWeight:'700',letterSpacing:-1.3,color:'#111',marginBottom:10},sub:{fontSize:15,lineHeight:22,color:'#66665F'},authCard:{marginTop:28},input:{height:54,borderBottomWidth:1,borderBottomColor:'#DDDCD6',fontSize:16,color:'#111'},button:{height:54,borderRadius:16,backgroundColor:'#111',alignItems:'center',justifyContent:'center',marginTop:18},buttonSecondary:{backgroundColor:'#E8E8E3'},buttonText:{color:'#fff',fontSize:15,fontWeight:'700'},buttonSecondaryText:{color:'#111'},switch:{textAlign:'center',marginTop:18,fontSize:14,fontWeight:'600',color:'#55554F'},tiny:{fontSize:12,lineHeight:18,color:'#8B8B84',marginTop:20},content:{padding:22,paddingTop:30,paddingBottom:110},card:{backgroundColor:'#fff',borderRadius:24,padding:20,marginBottom:14,borderWidth:1,borderColor:'#ECECE6'},direction:{padding:22,marginTop:16,marginBottom:26},cardLabel:{fontSize:10,letterSpacing:1.5,fontWeight:'800',color:'#8A8A83',marginBottom:10},directionText:{fontSize:25,lineHeight:31,fontWeight:'700',letterSpacing:-.7,color:'#111',marginBottom:10},muted:{fontSize:13,lineHeight:19,color:'#777770'},rowBetween:{flexDirection:'row',alignItems:'center',justifyContent:'space-between'},sectionTitle:{fontSize:18,fontWeight:'700',color:'#111',marginBottom:12},habitRow:{minHeight:68,flexDirection:'row',alignItems:'center',gap:14,borderBottomWidth:1,borderBottomColor:'#E9E9E3'},check:{width:25,height:25,borderRadius:9,borderWidth:1.5,borderColor:'#C8C8C0',alignItems:'center',justifyContent:'center'},checkDone:{backgroundColor:'#111',borderColor:'#111'},checkMark:{color:'#fff',fontWeight:'800'},habitTitle:{fontSize:15,fontWeight:'650',color:'#151515',marginBottom:3},done:{textDecorationLine:'line-through',color:'#888'},area:{padding:16},progressTrack:{height:6,borderRadius:5,backgroundColor:'#E8E8E3',overflow:'hidden',marginTop:8},progressFill:{height:6,borderRadius:5,backgroundColor:'#111'},lifeCard:{padding:20},bigNumber:{fontSize:38,fontWeight:'700',letterSpacing:-1,marginBottom:12},exploreCard:{padding:21},exploreTitle:{fontSize:22,lineHeight:27,fontWeight:'700',letterSpacing:-.5,marginBottom:8},save:{fontSize:14,fontWeight:'700',color:'#111',marginTop:15},nav:{position:'absolute',bottom:0,left:0,right:0,height:78,backgroundColor:'rgba(247,247,245,.97)',borderTopWidth:1,borderTopColor:'#E6E6E0',flexDirection:'row',justifyContent:'space-around',paddingTop:12},navItem:{alignItems:'center',gap:5,minWidth:65},navDot:{width:5,height:5,borderRadius:3,backgroundColor:'transparent'},navDotActive:{backgroundColor:'#111'},navText:{fontSize:11,color:'#96968E'},navTextActive:{color:'#111',fontWeight:'700'},sync:{position:'absolute',top:8,right:16,fontSize:10,color:'#999'} });
