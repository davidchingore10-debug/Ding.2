# DING — Official Expo + GitHub Build

DING is a personal growth app built around one loop:

**Direction → Understanding → Action → Habit → Evidence → Reflection**

## Repository

- `mobile/` — Expo / React Native app
- `server/` — connected API with persistent development storage
- `docs/` — launch and release checklist
- `.github/workflows/` — CI checks

## Run mobile

```bash
cd mobile
npm install
npx expo start
```

## Run API

```bash
cd server
DING_JWT_SECRET="replace-with-a-long-random-secret" npm start
```

The mobile app currently points to `http://localhost:4000`. For a physical phone, replace `API_URL` in `mobile/App.js` with your deployed HTTPS API URL before release.

## Important

This is now a connected release candidate foundation, not a store-ready production service. Before public launch, use a managed production database, HTTPS, secret management, rate limiting, monitoring/backups, production AI integration, privacy/support pages, final icons/assets, and store accounts.
