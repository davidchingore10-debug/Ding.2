# DING — V1.4

DING is a personal growth app built around one loop:

**Direction → Understanding → Action → Habit → Evidence → Reflection**

## V1.4

The mobile experience now has a clearer daily dashboard, completion progress, a next-best-action card, life-area overview, saved Explore content, and a DING reflection surface connected to the existing API.

### Run mobile

```bash
cd mobile
npm install
npx expo start
```

### Run API

```bash
cd server
DING_JWT_SECRET="replace-with-a-long-random-secret" npm start
```

The mobile app currently points to `http://localhost:4000`. For a physical phone, replace `API_URL` in `mobile/App.js` with your deployed HTTPS API URL.

## Important

This is a connected prototype, not a store-ready production service. Before launch, use managed production storage, HTTPS, secret management, rate limiting, monitoring/backups, production AI integration, final icons/assets, privacy/support pages, and store credentials.
