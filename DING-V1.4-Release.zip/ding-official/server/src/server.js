import http from 'node:http';
import crypto from 'node:crypto';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const DATA_DIR = path.join(__dirname, '..', 'data');
const DB_FILE = path.join(DATA_DIR, 'db.json');
const PORT = Number(process.env.PORT || 4000);
const JWT_SECRET = process.env.DING_JWT_SECRET || 'change-this-secret-before-production';

fs.mkdirSync(DATA_DIR, { recursive: true });
if (!fs.existsSync(DB_FILE)) fs.writeFileSync(DB_FILE, JSON.stringify({ users: [], sessions: [] }, null, 2));

function loadDb() { return JSON.parse(fs.readFileSync(DB_FILE, 'utf8')); }
function saveDb(db) {
  const tmp = DB_FILE + '.tmp';
  fs.writeFileSync(tmp, JSON.stringify(db, null, 2));
  fs.renameSync(tmp, DB_FILE);
}
function id() { return crypto.randomUUID(); }
function hashPassword(password, salt = crypto.randomBytes(16).toString('hex')) {
  const hash = crypto.scryptSync(password, salt, 64).toString('hex');
  return `${salt}:${hash}`;
}
function verifyPassword(password, stored) {
  const [salt, expected] = stored.split(':');
  const actual = crypto.scryptSync(password, salt, 64).toString('hex');
  return crypto.timingSafeEqual(Buffer.from(actual, 'hex'), Buffer.from(expected, 'hex'));
}
function b64(v) { return Buffer.from(v).toString('base64url'); }
function tokenFor(userId) {
  const head = b64(JSON.stringify({ alg: 'HS256', typ: 'JWT' }));
  const body = b64(JSON.stringify({ sub: userId, exp: Math.floor(Date.now() / 1000) + 60 * 60 * 24 * 30 }));
  const sig = crypto.createHmac('sha256', JWT_SECRET).update(`${head}.${body}`).digest('base64url');
  return `${head}.${body}.${sig}`;
}
function userFromToken(token) {
  if (!token) return null;
  const [head, body, sig] = token.split('.');
  if (!head || !body || !sig) return null;
  const expected = crypto.createHmac('sha256', JWT_SECRET).update(`${head}.${body}`).digest('base64url');
  if (!crypto.timingSafeEqual(Buffer.from(sig), Buffer.from(expected))) return null;
  const payload = JSON.parse(Buffer.from(body, 'base64url').toString());
  if (!payload.exp || payload.exp < Math.floor(Date.now() / 1000)) return null;
  const db = loadDb();
  return db.users.find(u => u.id === payload.sub) || null;
}
async function body(req) {
  let raw = '';
  for await (const chunk of req) raw += chunk;
  return raw ? JSON.parse(raw) : {};
}
function send(res, status, data) {
  res.writeHead(status, { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*', 'Access-Control-Allow-Headers': 'Content-Type, Authorization', 'Access-Control-Allow-Methods': 'GET,POST,PUT,DELETE,OPTIONS' });
  res.end(JSON.stringify(data));
}
function publicUser(u) { return { id: u.id, email: u.email, name: u.name, createdAt: u.createdAt }; }
function defaultState() {
  return {
    direction: 'Build a life you are proud to wake up to.',
    habits: [
      { id: 'focus', title: 'One focused hour', meta: 'Protect your attention', done: false },
      { id: 'learn', title: 'Learn something useful', meta: '20 minutes', done: false },
      { id: 'move', title: 'Move your body', meta: 'Walk, train, or stretch', done: false }
    ],
    areas: [
      { id: 'mind', title: 'Mind', progress: 42 },
      { id: 'health', title: 'Health', progress: 28 },
      { id: 'work', title: 'Work', progress: 35 },
      { id: 'relationships', title: 'Relationships', progress: 58 }
    ],
    saved: []
  };
}
function requireUser(req, res) {
  const auth = req.headers.authorization || '';
  const user = userFromToken(auth.startsWith('Bearer ') ? auth.slice(7) : null);
  if (!user) { send(res, 401, { error: 'Authentication required' }); return null; }
  return user;
}

const server = http.createServer(async (req, res) => {
  if (req.method === 'OPTIONS') return send(res, 204, {});
  try {
    const url = new URL(req.url, `http://${req.headers.host || 'localhost'}`);
    const db = loadDb();

    if (req.method === 'GET' && url.pathname === '/v1/health') return send(res, 200, { ok: true, service: 'ding-api', time: new Date().toISOString() });

    if (req.method === 'POST' && url.pathname === '/v1/auth/signup') {
      const { email, password, name } = await body(req);
      const normalized = String(email || '').trim().toLowerCase();
      if (!normalized || !normalized.includes('@') || String(password || '').length < 8) return send(res, 400, { error: 'Use a valid email and a password of at least 8 characters.' });
      if (db.users.some(u => u.email === normalized)) return send(res, 409, { error: 'An account with that email already exists.' });
      const user = { id: id(), email: normalized, name: String(name || 'DING member').trim().slice(0, 60), passwordHash: hashPassword(password), createdAt: new Date().toISOString(), state: defaultState(), stateVersion: 1 };
      db.users.push(user); saveDb(db);
      return send(res, 201, { token: tokenFor(user.id), user: publicUser(user), state: user.state, version: user.stateVersion });
    }

    if (req.method === 'POST' && url.pathname === '/v1/auth/login') {
      const { email, password } = await body(req);
      const user = db.users.find(u => u.email === String(email || '').trim().toLowerCase());
      if (!user || !verifyPassword(String(password || ''), user.passwordHash)) return send(res, 401, { error: 'Email or password is incorrect.' });
      return send(res, 200, { token: tokenFor(user.id), user: publicUser(user), state: user.state, version: user.stateVersion });
    }

    const user = requireUser(req, res);
    if (!user) return;

    if (req.method === 'GET' && url.pathname === '/v1/me') return send(res, 200, { user: publicUser(user) });
    if (req.method === 'GET' && url.pathname === '/v1/state') return send(res, 200, { state: user.state, version: user.stateVersion });

    if (req.method === 'PUT' && url.pathname === '/v1/state') {
      const { state, version } = await body(req);
      if (!state || typeof version !== 'number') return send(res, 400, { error: 'state and version are required' });
      if (version !== user.stateVersion) return send(res, 409, { error: 'State conflict', state: user.state, version: user.stateVersion });
      user.state = state; user.stateVersion += 1; saveDb(db);
      return send(res, 200, { state: user.state, version: user.stateVersion });
    }

    if (req.method === 'DELETE' && url.pathname === '/v1/account') {
      db.users = db.users.filter(u => u.id !== user.id); saveDb(db); return send(res, 200, { ok: true });
    }

    if (req.method === 'GET' && url.pathname === '/v1/privacy/export') return send(res, 200, { exportedAt: new Date().toISOString(), user: publicUser(user), state: user.state });

    if (req.method === 'POST' && url.pathname === '/v1/intelligence/query') {
      const { prompt } = await body(req);
      return send(res, 200, { answer: `DING reflection placeholder: ${String(prompt || '').slice(0, 500)}` });
    }

    return send(res, 404, { error: 'Not found' });
  } catch (error) {
    console.error(error);
    return send(res, 500, { error: 'Internal server error' });
  }
});

server.listen(PORT, () => console.log(`DING API running on http://localhost:${PORT}`));
