# DING API

A dependency-light connected backend for the DING mobile app.

## Run

```bash
DING_JWT_SECRET="replace-with-a-long-random-secret" npm start
```

The service persists users and app state to `server/data/db.json` for the development/early prototype stage.

## Endpoints

- `GET /v1/health`
- `POST /v1/auth/signup`
- `POST /v1/auth/login`
- `GET /v1/me`
- `GET /v1/state`
- `PUT /v1/state` (optimistic versioning)
- `DELETE /v1/account`
- `GET /v1/privacy/export`
- `POST /v1/intelligence/query`

## Before public production

Replace file persistence with a managed database, put the API behind HTTPS, rotate the JWT secret into a secret manager, add rate limiting, structured logging, backups, monitoring, email verification/password reset, and proper production AI provider integration.
