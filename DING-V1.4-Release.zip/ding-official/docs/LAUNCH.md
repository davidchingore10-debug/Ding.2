# DING launch path

```text
POLISHED APP
   ↓
GitHub repository
   ↓
CI checks
   ↓
HTTPS API + managed database
   ↓
EAS project + credentials
   ↓
Preview build on real device
   ↓
QA + privacy/support + store metadata
   ↓
Production EAS build
   ↓
Google Play / Apple App Store submission
   ↓
Monitor → improve → EAS Update
```

## Current state

- [x] Polished Expo mobile UI
- [x] Today / Life / Explore / You
- [x] Local persistence
- [x] Account creation + login UI
- [x] Secure token storage via Expo SecureStore
- [x] Connected state API
- [x] Versioned state sync
- [x] Account deletion endpoint
- [x] Privacy export endpoint
- [x] GitHub CI
- [ ] Deploy API to HTTPS host
- [ ] Move persistence to managed production database
- [ ] Set production DING_JWT_SECRET in secret manager
- [ ] Replace mobile API URL with production API URL
- [ ] Create EAS project and link project ID
- [ ] Add final icon / adaptive icon / splash artwork
- [ ] Add production AI provider behind server-side controls
- [ ] Test signup/login/sync/account deletion on real device
- [ ] Prepare privacy policy, support contact and store metadata
- [ ] Production EAS build
- [ ] Store submission

## Do not skip

Never commit API secrets, database credentials, signing credentials, or private tokens to GitHub. GitHub Actions secrets and EAS environment variables are designed for sensitive configuration.
